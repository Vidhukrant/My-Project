package com.racv.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

//import com.racv.utils.JSWaiter;

public class NextPage extends BasePage {
	public NextPage(WebDriver d) {
		super(d);
	}

	public void continueFlow() {
		
		//JSWaiter.waitUntilJSReady();
		//waitFor(3);
		//d.findElement(By.cssSelector(".continue-policy")).click();
	}

}
